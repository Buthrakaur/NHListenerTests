﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NHibernate.Event;
using NHibernate.Persister.Entity;

namespace NHListenerTest
{
	public class SetModificationDateListener : IPreInsertEventListener, IPreUpdateEventListener
	{
		public SetModificationDateListener()
		{
			CurrentDateTimeProvider = () => DateTime.Now;
		}

		public Func<DateTime> CurrentDateTimeProvider { get; set; }

		public bool OnPreInsert(PreInsertEvent @event)
		{
			SetModificationDateIfPossible(@event.Entity, @event.Persister, @event.State);
			return false;
		}

		private void SetModificationDateIfPossible(object entity, IEntityPersister persister, object[] state)
		{
			var trackable = entity as ITrackModificationDate;
			if (trackable != null)
			{
				trackable.LastModified = CurrentDateTimeProvider();
				persister.SetPropertyValue(state, "LastModified", trackable.LastModified);
			}
		}

		public bool OnPreUpdate(PreUpdateEvent @event)
		{
			SetModificationDateIfPossible(@event.Entity, @event.Persister, @event.State);
			return false;
		}
	}

	public static class IEntityPersisterExtensions
	{
		public static void SetPropertyValue(this IEntityPersister persister, object[] state, string propertyName, object value)
		{
			var index = Array.IndexOf(persister.PropertyNames, propertyName);
			if (index < 0) return;
			state[index] = value;
		}
	}
}
